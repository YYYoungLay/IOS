//
//  ViewController.swift
//  WeatherDemo
//
//  Created by student on 2018/12/17.
//  Copyright © 2018年 Young. All rights reserved.
//

import UIKit

class WeatherViewController: UIViewController {

    //MARK: Outlet

    var weather:[String:String]?
    
    @IBOutlet weak var topTemp: UILabel!
    @IBOutlet weak var LowTemp: UILabel!
    @IBOutlet weak var wea: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        topTemp.text = weather?["temp1"]
        LowTemp.text = weather?["temp2"]
        wea.text = weather?["weather"]
        
    }
}

